/**
 * Online Auto-Update Module for Khmer Dubbing Studio
 * 
 * Features:
 * - Lightweight Delta Patching (downloads only updated JS, CSS, HTML, and engine files: ~5-15MB)
 * - Safe & Non-Destructive: Never modifies licenses, registry, user data, or export folders
 * - Follows HTTP/HTTPS redirects (GitHub Releases, Cloudflare, S3, custom VPS)
 * - Real-time download progress tracking
 * - Native Windows extraction (zero extra npm dependencies)
 */

const fs = require('fs');
const path = require('path');
const https = require('https');
const http = require('http');
const { app } = require('electron');
const { execSync, spawn } = require('child_process');
const crypto = require('crypto');

// Default manifest URL (can be customized via config.json or AdminKeygen)
const DEFAULT_MANIFEST_URL = "https://raw.githubusercontent.com/tithyaka/khmer-dubbing-pro/main/updates/version.json";

const LOCAL_APPDATA = process.env.LOCALAPPDATA || (process.env.USERPROFILE ? path.join(process.env.USERPROFILE, 'AppData', 'Local') : '');
const UPDATES_DIR = path.join(LOCAL_APPDATA || '.', 'KhmerDubbing', 'updates');

function ensureDirSync(dirPath) {
  try {
    if (dirPath && !fs.existsSync(dirPath)) {
      fs.mkdirSync(dirPath, { recursive: true });
    }
  } catch (e) {}
}

/**
 * Compare two semver strings: returns 1 if v1 > v2, -1 if v1 < v2, 0 if equal.
 */
function compareSemver(v1, v2) {
  const clean1 = String(v1 || '0.0.0').trim().replace(/^[vV]/, '');
  const clean2 = String(v2 || '0.0.0').trim().replace(/^[vV]/, '');
  
  const p1 = clean1.split('.').map(n => parseInt(n, 10) || 0);
  const p2 = clean2.split('.').map(n => parseInt(n, 10) || 0);
  
  for (let i = 0; i < Math.max(p1.length, p2.length); i++) {
    const num1 = p1[i] || 0;
    const num2 = p2[i] || 0;
    if (num1 > num2) return 1;
    if (num1 < num2) return -1;
  }
  return 0;
}

/**
 * Fetch remote JSON over HTTP/HTTPS with redirect following and timeout.
 */
function fetchRemoteJson(urlStr, timeoutMs = 8000) {
  return new Promise((resolve, reject) => {
    try {
      const parsedUrl = new URL(urlStr);
      const client = parsedUrl.protocol === 'http:' ? http : https;
      
      const req = client.get(urlStr, {
        headers: {
          'User-Agent': 'KhmerDubbingPro-AutoUpdater/1.1',
          'Accept': 'application/json'
        },
        timeout: timeoutMs
      }, (res) => {
        // Handle HTTP 301, 302, 307, 308 redirects
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
          const redirectUrl = new URL(res.headers.location, parsedUrl).toString();
          return resolve(fetchRemoteJson(redirectUrl, timeoutMs));
        }

        if (res.statusCode !== 200) {
          return reject(new Error(`Server returned HTTP status ${res.statusCode}`));
        }

        let rawData = '';
        res.setEncoding('utf8');
        res.on('data', chunk => { rawData += chunk; });
        res.on('end', () => {
          try {
            const parsed = JSON.parse(rawData);
            resolve(parsed);
          } catch (e) {
            reject(new Error('Failed to parse update manifest JSON: ' + e.message));
          }
        });
      });

      req.on('timeout', () => {
        req.destroy();
        reject(new Error('Update server check timed out.'));
      });

      req.on('error', err => {
        reject(err);
      });
    } catch (e) {
      reject(e);
    }
  });
}

/**
 * Check if a newer version is available online.
 */
async function checkForUpdates(currentVersion, manifestUrlOverride = null) {
  const manifestUrl = manifestUrlOverride || DEFAULT_MANIFEST_URL;
  try {
    const data = await fetchRemoteJson(manifestUrl, 8000);
    const remoteVersion = data.version || data.latest_version;
    
    if (!remoteVersion) {
      return { updateAvailable: false, error: 'Manifest missing version field.' };
    }

    const isNewer = compareSemver(remoteVersion, currentVersion) > 0;
    return {
      updateAvailable: isNewer,
      currentVersion,
      newVersion: remoteVersion,
      releaseDate: data.release_date || new Date().toISOString().substring(0, 10),
      changelog: data.changelog || 'Performance and stability improvements.',
      downloadUrl: data.download_url || data.patch_url || '',
      fileSizeMb: data.size_mb || null,
      mandatory: !!data.mandatory,
      sha256: data.sha256 || null,
      manifestUrl
    };
  } catch (err) {
    return {
      updateAvailable: false,
      currentVersion,
      error: err.message,
      manifestUrl
    };
  }
}

/**
 * Download a file with redirect following, streaming to disk, and progress reporting.
 */
function downloadFile(urlStr, targetPath, onProgress) {
  return new Promise((resolve, reject) => {
    try {
      const parsedUrl = new URL(urlStr);
      const client = parsedUrl.protocol === 'http:' ? http : https;

      const req = client.get(urlStr, {
        headers: {
          'User-Agent': 'KhmerDubbingPro-AutoUpdater/1.1'
        }
      }, (res) => {
        // Follow redirects (e.g. GitHub Releases redirect to S3)
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
          const redirectUrl = new URL(res.headers.location, parsedUrl).toString();
          return resolve(downloadFile(redirectUrl, targetPath, onProgress));
        }

        if (res.statusCode !== 200) {
          return reject(new Error(`Download failed with HTTP status ${res.statusCode}`));
        }

        const totalBytes = parseInt(res.headers['content-length'] || '0', 10);
        let downloadedBytes = 0;
        let lastReportTime = Date.now();
        let lastBytes = 0;

        ensureDirSync(path.dirname(targetPath));
        const fileStream = fs.createWriteStream(targetPath);

        res.on('data', chunk => {
          downloadedBytes += chunk.length;
          fileStream.write(chunk);

          const now = Date.now();
          if (now - lastReportTime >= 150) {
            const timeDiffSec = (now - lastReportTime) / 1000;
            const bytesDiff = downloadedBytes - lastBytes;
            const speedBytesPerSec = timeDiffSec > 0 ? (bytesDiff / timeDiffSec) : 0;
            const speedMb = (speedBytesPerSec / (1024 * 1024)).toFixed(2);
            const percent = totalBytes > 0 ? Math.min(100, Math.round((downloadedBytes / totalBytes) * 100)) : 0;

            if (typeof onProgress === 'function') {
              onProgress({
                percent,
                downloadedBytes,
                totalBytes,
                downloadedMb: (downloadedBytes / (1024 * 1024)).toFixed(1),
                totalMb: (totalBytes / (1024 * 1024)).toFixed(1),
                speedMb
              });
            }

            lastReportTime = now;
            lastBytes = downloadedBytes;
          }
        });

        res.on('end', () => {
          fileStream.end(() => {
            if (typeof onProgress === 'function') {
              onProgress({
                percent: 100,
                downloadedBytes,
                totalBytes: downloadedBytes,
                downloadedMb: (downloadedBytes / (1024 * 1024)).toFixed(1),
                totalMb: (downloadedBytes / (1024 * 1024)).toFixed(1),
                speedMb: '0.00'
              });
            }
            resolve(targetPath);
          });
        });

        res.on('error', err => {
          fileStream.close();
          try { fs.unlinkSync(targetPath); } catch (e) {}
          reject(err);
        });
      });

      req.on('error', err => {
        reject(err);
      });
    } catch (e) {
      reject(e);
    }
  });
}

/**
 * Apply the downloaded patch zip over the running app files.
 * Extracts into app resources or project directory using native Windows PowerShell Expand-Archive.
 */
function applyPatchZip(zipPath) {
  ensureDirSync(UPDATES_DIR);

  // Determine root destination
  let destDir = '';
  if (app.isPackaged) {
    // For packaged app: replace files in process.resourcesPath
    destDir = process.resourcesPath;
  } else {
    // For development: project root
    destDir = path.resolve(__dirname, '..');
  }

  // Windows PowerShell native extraction
  const escapedZip = zipPath.replace(/'/g, "''");
  const escapedDest = destDir.replace(/'/g, "''");

  const psScript = `
    $ErrorActionPreference = 'Stop'
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [System.IO.Compression.ZipFile]::ExtractToDirectory('${escapedZip}', '${escapedDest}', $true)
  `;

  try {
    execSync(`powershell -NoProfile -NonInteractive -Command "${psScript.replace(/\r?\n/g, ' ')}"`, {
      windowsHide: true,
      stdio: 'pipe',
      timeout: 30000
    });
    return { success: true };
  } catch (err) {
    // Fallback using Expand-Archive
    try {
      execSync(`powershell -NoProfile -Command "Expand-Archive -LiteralPath '${escapedZip}' -DestinationPath '${escapedDest}' -Force"`, {
        windowsHide: true,
        stdio: 'pipe',
        timeout: 45000
      });
      return { success: true };
    } catch (e2) {
      return { success: false, error: e2.message || err.message };
    }
  }
}

/**
 * Relaunch the application after update.
 */
function restartApp() {
  app.relaunch();
  app.exit(0);
}

module.exports = {
  DEFAULT_MANIFEST_URL,
  UPDATES_DIR,
  checkForUpdates,
  downloadFile,
  applyPatchZip,
  restartApp,
  compareSemver
};
