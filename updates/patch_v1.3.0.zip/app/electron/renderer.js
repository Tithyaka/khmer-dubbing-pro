// ── Application State ────────────────────────────────────────────────────────
let appState = {
  queue: [], // Array of { path, name, duration_sec, size_bytes, already_dubbed, existing_output, status }
  systemStatus: null,
  isDubbing: false,
  lastCompletedPath: null,
  lastExportDir: null,
  isLicensed: false,
  isLifetime: false,
  licenseExpiryTs: null,
  expiryStr: 'N/A',
  licenseKey: '',
};

// ── DOM Elements ─────────────────────────────────────────────────────────────
const liveClock = document.getElementById('liveClock');
const txtLiveClock = document.getElementById('txtLiveClock');
const btnLicenseStatus = document.getElementById('btnLicenseStatus');
const txtLicenseStatus = document.getElementById('txtLicenseStatus');
const btnTelegram = document.getElementById('btnTelegram');
const btnOpenSettings = document.getElementById('btnOpenSettings');

const activeLicenseCard = document.getElementById('activeLicenseCard');
const activeBadgeText = document.getElementById('activeBadgeText');
const txtModalRealtime = document.getElementById('txtModalRealtime');
const txtModalCountdown = document.getElementById('txtModalCountdown');
const txtModalExpiry = document.getElementById('txtModalExpiry');
const txtModalKey = document.getElementById('txtModalKey');

const btnImportFiles = document.getElementById('btnImportFiles');
const btnImportFolder = document.getElementById('btnImportFolder');
const btnClearQueue = document.getElementById('btnClearQueue');
const btnOpenExportDir = document.getElementById('btnOpenExportDir');
const btnStartDubbing = document.getElementById('btnStartDubbing');
const btnCancelDubbing = document.getElementById('btnCancelDubbing');

const queueCountBadge = document.getElementById('queueCountBadge');
const totalDurationLabel = document.getElementById('totalDurationLabel');
const dropZone = document.getElementById('dropZone');
const dragDropOverlay = document.getElementById('dragDropOverlay');
const queueTableContainer = document.getElementById('queueTableContainer');
const queueTableBody = document.getElementById('queueTableBody');

const selVocalMode = document.getElementById('selVocalMode');
const chkSkipAlreadyDubbed = document.getElementById('chkSkipAlreadyDubbed');
const txtExportFolder = document.getElementById('txtExportFolder');
const btnBrowseExport = document.getElementById('btnBrowseExport');

const pipelineStatusLabel = document.getElementById('pipelineStatusLabel');
const currentActionLabel = document.getElementById('currentActionLabel');
const progressPercentLabel = document.getElementById('progressPercentLabel');
const progressBarFill = document.getElementById('progressBarFill');
const batchCounterText = document.getElementById('batchCounterText');

const stageStep1 = document.getElementById('stageStep1');
const stageStep2 = document.getElementById('stageStep2');
const stageStep3 = document.getElementById('stageStep3');
const stageStep4 = document.getElementById('stageStep4');
const stageStep5 = document.getElementById('stageStep5');

const logTerminal = document.getElementById('logTerminal');
const chkAutoScroll = document.getElementById('chkAutoScroll');
const btnClearLog = document.getElementById('btnClearLog');

// Modals
const modalActivation = document.getElementById('modalActivation');
const btnCloseActivation = document.getElementById('btnCloseActivation');
const txtMachineId = document.getElementById('txtMachineId');
const btnCopyMachineId = document.getElementById('btnCopyMachineId');
const txtActivationKey = document.getElementById('txtActivationKey');
const activationAlert = document.getElementById('activationAlert');
const btnContactTelegram = document.getElementById('btnContactTelegram');
const btnSubmitActivation = document.getElementById('btnSubmitActivation');

const modalSettings = document.getElementById('modalSettings');
const btnCloseSettings = document.getElementById('btnCloseSettings');
const txtSettingsExportDir = document.getElementById('txtSettingsExportDir');
const btnSettingsBrowseDir = document.getElementById('btnSettingsBrowseDir');
const chkSettingsCreateMovieFolder = document.getElementById('chkSettingsCreateMovieFolder');
const chkSettingsAutoOpen = document.getElementById('chkSettingsAutoOpen');
const chkSettingsSkipDubbed = document.getElementById('chkSettingsSkipDubbed');
const btnSaveSettings = document.getElementById('btnSaveSettings');

// ── Logging Helper ───────────────────────────────────────────────────────────
function addLog(msg, level = 'info') {
  const line = document.createElement('div');
  line.className = `log-line ${level}`;

  const now = new Date();
  const timeStr = `[${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}]`;

  line.innerHTML = `
    <span class="log-time">${timeStr}</span>
    <span class="log-badge ${level}">${level.toUpperCase()}</span>
    <span class="log-msg">${escapeHtml(msg)}</span>
  `;

  logTerminal.appendChild(line);

  if (chkAutoScroll.checked) {
    logTerminal.scrollTop = logTerminal.scrollHeight;
  }
}

function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function formatDuration(sec) {
  if (!sec || isNaN(sec)) return '--:--';
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${m}:${String(s).padStart(2, '0')}`;
}

function formatBytes(bytes) {
  if (!bytes) return '0 MB';
  const mb = bytes / (1024 * 1024);
  return `${mb.toFixed(1)} MB`;
}

// ── Startup & Initialization ─────────────────────────────────────────────────
async function initApp() {
  // Start 1-second ticking clock and license countdown
  updateRealtimeClockAndCountdown();
  setInterval(updateRealtimeClockAndCountdown, 1000);

  // Initialize Software Version
  let currentVer = '1.3.0';
  try {
    if (window.api && typeof window.api.getAppVersion === 'function') {
      const ver = await window.api.getAppVersion();
      if (ver) currentVer = ver;
    }
  } catch (e) {}
  appState.currentVersion = currentVer;
  updateAppVersionDisplay(currentVer);

  // Check if app was just updated to celebrate and alert user
  try {
    const justUpdated = localStorage.getItem('just_updated_to');
    if (justUpdated) {
      localStorage.removeItem('just_updated_to');
      setTimeout(() => {
        showToast('🎉 Welcome to Version ' + justUpdated + '!', 'Software successfully updated. You are running the newest release.', 'success', 8000);
        addLog(`🎉 Welcome to Khmer Dubbing Studio v${justUpdated}! Running latest version.`, 'success');
        playUpdateSuccessChime();
      }, 600);
    }
  } catch (e) {}

  try {
    addLog('Connecting to backend dubbing engine...', 'info');
    const status = await window.api.getStatus();
    appState.systemStatus = status;

    if (status && status.app_version) {
      appState.currentVersion = status.app_version;
      updateAppVersionDisplay(status.app_version);
    }

    if (status.success) {
      updateLicenseDisplay(status);

      if (status.config) {
        if (status.config.export_folder) {
          txtExportFolder.value = status.config.export_folder;
          txtSettingsExportDir.value = status.config.export_folder;
          appState.lastExportDir = status.config.export_folder;
        }
        if (status.config.vocal_mode) {
          selVocalMode.value = status.config.vocal_mode;
        }
        if (status.config.skip_already_dubbed !== undefined) {
          chkSkipAlreadyDubbed.checked = status.config.skip_already_dubbed;
          chkSettingsSkipDubbed.checked = status.config.skip_already_dubbed;
        }
        if (status.config.auto_open_output !== undefined) {
          chkSettingsAutoOpen.checked = !!status.config.auto_open_output;
        }
      }

      txtMachineId.value = status.machine_id || 'UNKNOWN';

      addLog(`Hardware ID: ${status.machine_id}`, 'info');
      addLog(`License Status: ${status.license_status || 'Trial'}`, status.licensed ? 'success' : 'warning');
      if (status.ffmpeg) {
        addLog('FFmpeg media engine active & verified.', 'success');
      }
      if (status.tts) {
        addLog('Neural TTS provider available.', 'success');
      }
    } else {
      addLog(`Engine warning: ${status.error || 'Check environment'}`, 'warning');
    }
  } catch (err) {
    addLog(`Error initializing engine: ${err.message}`, 'error');
  }
}

function setWorkspaceLocked(locked) {
  btnImportFiles.disabled = locked;
  btnImportFolder.disabled = locked;
  btnStartDubbing.disabled = locked;
  btnClearQueue.disabled = locked;
  btnOpenExportDir.disabled = locked;
  // Preferences ⚙️ is always accessible so user can configure export folder & vocal mode
  btnOpenSettings.disabled = false;

  if (locked) {
    dropZone.classList.add('locked-disabled');
    const dropContent = dropZone.querySelector('.drop-zone-content');
    if (dropContent) {
      dropContent.querySelector('.drop-title').textContent = '🔒 Software Locked — Activation Required';
      dropContent.querySelector('.drop-sub').textContent = 'Please enter your license key to unlock dubbing and video import.';
    }
    modalActivation.classList.remove('hidden');
  } else {
    dropZone.classList.remove('locked-disabled');
    const dropContent = dropZone.querySelector('.drop-zone-content');
    if (dropContent) {
      dropContent.querySelector('.drop-title').textContent = 'Drag & drop video files or folders here';
      dropContent.querySelector('.drop-sub').textContent = 'Supports MP4, MKV, AVI, MOV, WEBM, M4V, TS';
    }
    modalActivation.classList.add('hidden');
  }
}

function updateRealtimeClockAndCountdown() {
  const now = new Date();
  const h = String(now.getHours()).padStart(2, '0');
  const m = String(now.getMinutes()).padStart(2, '0');
  const s = String(now.getSeconds()).padStart(2, '0');
  const timeStr = `${h}:${m}:${s}`;
  const dateStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;

  if (txtLiveClock) {
    txtLiveClock.textContent = timeStr;
    if (liveClock) {
      liveClock.title = `Local System Realtime: ${dateStr} ${timeStr}`;
    }
  }

  if (txtModalRealtime) {
    txtModalRealtime.textContent = `🕒 Realtime: ${timeStr}`;
  }

  // Handle License Display
  if (!appState.isLicensed) {
    if (appState.isTrial) {
      btnLicenseStatus.className = 'badge-license trial-expired';
      txtLicenseStatus.textContent = '⚠️ Trial Expired (Buy Key)';
      btnLicenseStatus.title = 'Your 3-hour free trial has expired. Click to enter activation key.';
    } else {
      btnLicenseStatus.className = 'badge-license trial';
      txtLicenseStatus.textContent = '🔒 Activate License';
      btnLicenseStatus.title = 'Software is locked. Click to enter activation key.';
    }
    if (activeLicenseCard) activeLicenseCard.classList.add('hidden');
    return;
  }

  if (appState.isLifetime) {
    btnLicenseStatus.className = 'badge-license active';
    txtLicenseStatus.textContent = '⚡ Lifetime License';
    btnLicenseStatus.title = 'Permanent Lifetime License (Never Expires)';
    if (activeLicenseCard) {
      activeLicenseCard.classList.remove('hidden');
      if (activeBadgeText) activeBadgeText.textContent = '⚡ Lifetime License';
      if (txtModalCountdown) txtModalCountdown.textContent = 'Permanent (Never Expires)';
      if (txtModalExpiry) txtModalExpiry.textContent = 'Never (Lifetime)';
      if (txtModalKey) txtModalKey.textContent = appState.licenseKey || 'Registered';
    }
    return;
  }

  if (appState.licenseExpiryTs) {
    const nowTs = Math.floor(Date.now() / 1000);
    const diff = appState.licenseExpiryTs - nowTs;

    if (diff <= 0) {
      if (appState.isTrial) {
        btnLicenseStatus.className = 'badge-license trial-expired';
        txtLicenseStatus.textContent = '⚠️ Trial Expired (Buy Key)';
        btnLicenseStatus.title = `Your 3-hour free trial expired on ${appState.expiryStr || 'N/A'}. Click to activate license.`;
      } else {
        btnLicenseStatus.className = 'badge-license expired';
        txtLicenseStatus.textContent = '⚠️ License Expired';
        btnLicenseStatus.title = `Your license expired on ${appState.expiryStr || 'N/A'}. Click to renew.`;
      }

      if (activeLicenseCard) {
        activeLicenseCard.classList.remove('hidden');
        if (activeBadgeText) activeBadgeText.textContent = appState.isTrial ? '⚠️ Trial Expired' : '⚠️ License Expired';
        if (txtModalCountdown) txtModalCountdown.textContent = '00:00:00 (Expired)';
        if (txtModalExpiry) txtModalExpiry.textContent = appState.expiryStr || 'Expired';
        if (txtModalKey) txtModalKey.textContent = appState.licenseKey || '--';
      }
      setWorkspaceLocked(true);
      return;
    }

    const days = Math.floor(diff / 86400);
    const remSec = diff % 86400;
    const hours = Math.floor(remSec / 3600);
    const mins = Math.floor((remSec % 3600) / 60);
    const secs = remSec % 60;

    let badgeText = '';
    let detailedCountdown = '';

    if (appState.isTrial) {
      badgeText = `🎁 Free Trial (${hours}h ${mins}m ${secs}s)`;
      detailedCountdown = `${hours} Hours, ${mins} Minutes, ${secs} Seconds`;
      btnLicenseStatus.className = 'badge-license trial-active';
      txtLicenseStatus.textContent = badgeText;
      btnLicenseStatus.title = `3-Hour Free Trial | Expires: ${appState.expiryStr} | Remaining: ${detailedCountdown}`;
      if (activeLicenseCard) {
        activeLicenseCard.classList.remove('hidden');
        if (activeBadgeText) activeBadgeText.textContent = '🎁 Free Trial Active';
        if (txtModalCountdown) txtModalCountdown.textContent = detailedCountdown;
        if (txtModalExpiry) txtModalExpiry.textContent = appState.expiryStr || '--';
        if (txtModalKey) txtModalKey.textContent = '3-Hour Free Trial';
      }
      return;
    }

    if (days > 0) {
      badgeText = `⚡ Active (${days}d ${hours}h ${mins}m ${secs}s)`;
      detailedCountdown = `${days} Days, ${hours} Hours, ${mins} Minutes, ${secs} Seconds`;
    } else {
      // Under 24 hours: display live ticking countdown like 18h 42m 15s or HH:MM:SS
      badgeText = `⚡ Active (${hours}h ${mins}m ${secs}s)`;
      detailedCountdown = `${hours} Hours, ${mins} Minutes, ${secs} Seconds`;
    }

    btnLicenseStatus.className = 'badge-license active';
    txtLicenseStatus.textContent = badgeText;
    btnLicenseStatus.title = `Expires: ${appState.expiryStr} | Remaining: ${detailedCountdown}`;

    if (activeLicenseCard) {
      activeLicenseCard.classList.remove('hidden');
      if (activeBadgeText) activeBadgeText.textContent = '⚡ Active License';
      if (txtModalCountdown) txtModalCountdown.textContent = detailedCountdown;
      if (txtModalExpiry) txtModalExpiry.textContent = appState.expiryStr || '--';
      if (txtModalKey) txtModalKey.textContent = appState.licenseKey || '--';
    }
  }
}

function updateLicenseDisplay(status) {
  if (status && status.licensed) {
    appState.isLicensed = true;
    appState.isLifetime = !!status.is_lifetime;
    appState.isTrial = !!status.is_trial;
    appState.licenseExpiryTs = status.expiry_ts || null;
    appState.expiryStr = status.expiry_str || 'N/A';
    appState.licenseKey = status.license_key || '';
    setWorkspaceLocked(false);
  } else {
    appState.isLicensed = false;
    appState.isLifetime = false;
    appState.isTrial = !!(status && status.is_trial);
    appState.licenseExpiryTs = null;
    appState.expiryStr = 'N/A';
    appState.licenseKey = '';
    setWorkspaceLocked(true);
  }
  updateTrialBoxUI(status);
  updateRealtimeClockAndCountdown();
}

function updateTrialBoxUI(status) {
  const trialBoxContainer = document.getElementById('trialBoxContainer');
  const trialStatusBadge = document.getElementById('trialStatusBadge');
  const trialBoxDesc = document.getElementById('trialBoxDesc');
  const btnStartTrial = document.getElementById('btnStartTrial');
  if (!trialBoxContainer || !btnStartTrial) return;

  if (status && status.is_trial && status.licensed) {
    trialStatusBadge.className = 'trial-pill active';
    trialStatusBadge.textContent = 'Active';
    btnStartTrial.disabled = true;
    btnStartTrial.textContent = '✓ 3-Hour Free Trial is Active';
    trialBoxDesc.innerHTML = `Your free trial is currently running! Access expires on <strong>${status.expiry_str || ''}</strong>.`;
  } else if (status && !status.trial_eligible) {
    trialStatusBadge.className = 'trial-pill used';
    trialStatusBadge.textContent = 'Already Used';
    btnStartTrial.disabled = true;
    btnStartTrial.textContent = '❌ Trial Already Used on this PC';
    trialBoxDesc.innerHTML = 'This computer has already used its one-time 3-hour trial. Please enter an official activation license key above.';
  } else {
    trialStatusBadge.className = 'trial-pill available';
    trialStatusBadge.textContent = 'Available';
    btnStartTrial.disabled = false;
    btnStartTrial.textContent = '🎁 Start 3-Hour Free Trial';
    trialBoxDesc.innerHTML = 'Want to test before purchasing? Activate full video dubbing and export access for <strong>3 hours</strong> on this computer for free (1 time only).';
  }
}


// ── Queue Management ─────────────────────────────────────────────────────────
async function addFilesToQueue(filePaths) {
  if (!appState.systemStatus || !appState.systemStatus.licensed) {
    modalActivation.classList.remove('hidden');
    return;
  }
  if (!filePaths || filePaths.length === 0) return;

  addLog(`Inspecting ${filePaths.length} video file(s)...`, 'info');
  const res = await window.api.probeFiles(filePaths);

  if (res.success && res.files) {
    let addedCount = 0;
    for (const f of res.files) {
      if (!appState.queue.some(item => item.path === f.path)) {
        appState.queue.push({
          path: f.path,
          name: f.name,
          duration_sec: f.duration_sec,
          size_bytes: f.size_bytes,
          already_dubbed: f.already_dubbed,
          existing_output: f.existing_output,
          status: f.already_dubbed ? 'Skipped' : 'Pending'
        });
        addedCount++;
      }
    }
    renderQueueTable();
    addLog(`Added ${addedCount} video(s) to queue. Total: ${appState.queue.length}`, 'info');
  }
}

function renderQueueTable() {
  const count = appState.queue.length;
  queueCountBadge.textContent = `${count} Video${count === 1 ? '' : 's'}`;

  let totalSec = 0;
  for (const item of appState.queue) {
    totalSec += (item.duration_sec || 0);
  }
  totalDurationLabel.textContent = `Total: ${Math.floor(totalSec / 60)}m ${Math.floor(totalSec % 60)}s`;

  if (count === 0) {
    dropZone.querySelector('.drop-zone-content').classList.remove('hidden');
    queueTableContainer.classList.add('hidden');
    queueTableBody.innerHTML = '';
    batchCounterText.textContent = 'Queue: 0 items';
    return;
  }

  dropZone.querySelector('.drop-zone-content').classList.add('hidden');
  queueTableContainer.classList.remove('hidden');
  batchCounterText.textContent = `Queue: ${count} videos loaded`;

  queueTableBody.innerHTML = '';
  appState.queue.forEach((item, idx) => {
    const row = document.createElement('tr');
    row.id = `queueRow_${idx + 1}`;

    const numStr = `${idx + 1}/${count}`;
    let statusPill = `<span class="status-pill pending">Pending</span>`;
    if (item.status === 'Processing') {
      statusPill = `<span class="status-pill processing">Processing</span>`;
    } else if (item.status === 'Completed') {
      statusPill = `<span class="status-pill completed">✓ Done</span>`;
    } else if (item.status === 'Skipped') {
      statusPill = `<span class="status-pill skipped">⚡ Dubbed</span>`;
    } else if (item.status === 'Failed') {
      statusPill = `<span class="status-pill failed">✗ Failed</span>`;
    }

    row.innerHTML = `
      <td style="color: var(--text-muted); font-weight: 600;">${numStr}</td>
      <td title="${escapeHtml(item.path)}">
        <strong>${escapeHtml(item.name)}</strong>
      </td>
      <td>${formatDuration(item.duration_sec)}</td>
      <td>${formatBytes(item.size_bytes)}</td>
      <td>${statusPill}</td>
    `;

    queueTableBody.appendChild(row);
  });
}

// ── Drag & Drop Implementation ──────────────────────────────────────────────
function extractPathsFromDataTransfer(dataTransfer) {
  const paths = [];
  if (!dataTransfer) return paths;

  const files = dataTransfer.files;
  if (files && files.length > 0) {
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      let p = '';
      try {
        if (window.api && typeof window.api.getPathForFile === 'function') {
          p = window.api.getPathForFile(file);
        }
      } catch (err) {
        console.warn('getPathForFile failed:', err);
      }
      if (!p && file.path) {
        p = file.path;
      }
      if (p) {
        paths.push(p);
      }
    }
  }

  // Fallback for dataTransfer.items
  if (paths.length === 0 && dataTransfer.items && dataTransfer.items.length > 0) {
    for (let i = 0; i < dataTransfer.items.length; i++) {
      const item = dataTransfer.items[i];
      if (item.kind === 'file') {
        const file = item.getAsFile();
        if (file) {
          let p = '';
          try {
            if (window.api && typeof window.api.getPathForFile === 'function') {
              p = window.api.getPathForFile(file);
            }
          } catch (e) {}
          if (!p && file.path) p = file.path;
          if (p) paths.push(p);
        }
      }
    }
  }

  return paths;
}

let windowDragCounter = 0;

function showDragOverlay() {
  if (dragDropOverlay) dragDropOverlay.classList.remove('hidden');
  dropZone.classList.add('drag-over');
}

function hideDragOverlay() {
  if (dragDropOverlay) dragDropOverlay.classList.add('hidden');
  dropZone.classList.remove('drag-over');
}

async function handleDropFiles(dataTransfer) {
  const paths = extractPathsFromDataTransfer(dataTransfer);
  if (!paths || paths.length === 0) return;

  if (!appState.systemStatus || !appState.systemStatus.licensed) {
    addLog('Software is locked. Please activate your license to import videos.', 'warning');
    modalActivation.classList.remove('hidden');
    return;
  }

  addLog(`Received ${paths.length} dropped file(s)/folder(s). Processing...`, 'info');
  await addFilesToQueue(paths);
}

// Window-wide drag and drop listeners (prevents browser navigating to file & supports dropping anywhere)
window.addEventListener('dragenter', (e) => {
  e.preventDefault();
  e.stopPropagation();
  windowDragCounter++;
  if (e.dataTransfer && e.dataTransfer.types) {
    const types = Array.from(e.dataTransfer.types);
    if (types.includes('Files')) {
      showDragOverlay();
    }
  }
});

window.addEventListener('dragover', (e) => {
  e.preventDefault();
  e.stopPropagation();
  if (e.dataTransfer) {
    e.dataTransfer.dropEffect = 'copy';
  }
});

window.addEventListener('dragleave', (e) => {
  e.preventDefault();
  e.stopPropagation();
  windowDragCounter--;
  if (windowDragCounter <= 0) {
    windowDragCounter = 0;
    hideDragOverlay();
  }
});

window.addEventListener('drop', (e) => {
  e.preventDefault();
  e.stopPropagation();
  windowDragCounter = 0;
  hideDragOverlay();
  handleDropFiles(e.dataTransfer);
});


// ── Button Handlers ──────────────────────────────────────────────────────────
btnImportFiles.addEventListener('click', async () => {
  const files = await window.api.selectFiles();
  if (files && files.length > 0) {
    addFilesToQueue(files);
  }
});

btnImportFolder.addEventListener('click', async () => {
  const folder = await window.api.selectFolder();
  if (folder) {
    addFilesToQueue([folder]);
  }
});

btnClearQueue.addEventListener('click', () => {
  if (appState.isDubbing) return;
  appState.queue = [];
  renderQueueTable();
  addLog('Queue cleared.', 'info');
});

btnBrowseExport.addEventListener('click', async () => {
  const folder = await window.api.selectExportFolder();
  if (folder) {
    txtExportFolder.value = folder;
    txtSettingsExportDir.value = folder;
    appState.lastExportDir = folder;
    window.api.saveSettings({ export_folder: folder });
    addLog(`Export destination updated: ${folder}`, 'info');
  }
});

btnOpenExportDir.addEventListener('click', () => {
  const dir = txtExportFolder.value || appState.lastExportDir;
  if (dir) {
    window.api.openFolder(dir);
    addLog(`Opening folder: ${dir}`, 'info');
  }
});

btnClearLog.addEventListener('click', () => {
  logTerminal.innerHTML = '';
});

// ── Pipeline Stages Visualizer ───────────────────────────────────────────────
function updateStageVisualizer(stageIdx) {
  const stages = [stageStep1, stageStep2, stageStep3, stageStep4, stageStep5];
  stages.forEach((stg, i) => {
    const num = i + 1;
    if (num < stageIdx) {
      stg.className = 'stage-step completed';
    } else if (num === stageIdx) {
      stg.className = 'stage-step active';
    } else {
      stg.className = 'stage-step';
    }
  });
}

function resetStageVisualizer() {
  [stageStep1, stageStep2, stageStep3, stageStep4, stageStep5].forEach(s => {
    s.className = 'stage-step';
  });
}

function markAllStagesCompleted() {
  [stageStep1, stageStep2, stageStep3, stageStep4, stageStep5].forEach(s => {
    s.className = 'stage-step completed';
  });
}

// ── Dubbing Execution ────────────────────────────────────────────────────────
btnStartDubbing.addEventListener('click', async () => {
  if (appState.isDubbing) return;

  // 1. Check license
  if (!appState.systemStatus || !appState.systemStatus.licensed) {
    modalActivation.classList.remove('hidden');
    return;
  }

  // 2. Check queue
  if (appState.queue.length === 0) {
    alert('Please import at least one video to start dubbing!');
    return;
  }

  appState.isDubbing = true;
  btnStartDubbing.classList.add('hidden');
  btnCancelDubbing.classList.remove('hidden');
  btnImportFiles.disabled = true;
  btnImportFolder.disabled = true;
  btnClearQueue.disabled = true;

  pipelineStatusLabel.textContent = 'Processing Batch...';
  progressBarFill.style.width = '0%';
  progressPercentLabel.textContent = '0%';
  updateStageVisualizer(1);

  const filePaths = appState.queue.map(q => q.path);
  const options = {
    files: filePaths,
    vocalMode: selVocalMode.value,
    exportFolder: txtExportFolder.value,
    skipExisting: chkSkipAlreadyDubbed.checked,
  };

  addLog(`Starting dubbing batch (${filePaths.length} video(s))...`, 'processing');

  const startRes = await window.api.startDub(options);
  if (!startRes.started) {
    appState.isDubbing = false;
    btnStartDubbing.classList.remove('hidden');
    btnCancelDubbing.classList.add('hidden');
    btnImportFiles.disabled = false;
    btnImportFolder.disabled = false;
    btnClearQueue.disabled = false;
    pipelineStatusLabel.textContent = 'Failed to Start';
    addLog(`Failed to start dubbing: ${startRes.error}`, 'error');
  }
});

btnCancelDubbing.addEventListener('click', async () => {
  if (confirm('Cancel the current dubbing batch?')) {
    addLog('Cancelling dubbing process...', 'warning');
    await window.api.cancelDub();
  }
});

// ── Live Event Stream Listener ───────────────────────────────────────────────
window.api.onDubEvent((evt) => {
  if (!evt) return;

  const total = evt.total || appState.queue.length;
  const current = evt.current || 1;

  if (evt.type === 'file_start') {
    batchCounterText.textContent = `Dubbing video ${current} of ${total} (${evt.filename})`;
    currentActionLabel.textContent = `[${current}/${total}] Starting: ${evt.filename}`;
    updateQueueRowStatus(current, 'Processing');
    updateStageVisualizer(1);
    addLog(`[${current}/${total}] Starting: ${evt.filename}`, 'processing');
  }
  else if (evt.type === 'stage') {
    updateStageVisualizer(evt.stage_idx);
    currentActionLabel.textContent = `[${current}/${total}] Stage ${evt.stage_idx}/5: ${evt.details}`;
    progressBarFill.style.width = `${evt.percent}%`;
    progressPercentLabel.textContent = `${evt.percent}%`;
    addLog(`[${current}/${total}] Stage ${evt.stage_idx}/5: ${evt.details}`, 'info');
  }
  else if (evt.type === 'progress') {
    progressBarFill.style.width = `${evt.percent}%`;
    progressPercentLabel.textContent = `${evt.percent}%`;
    currentActionLabel.textContent = evt.message;
  }
  else if (evt.type === 'log') {
    addLog(evt.message, evt.status || 'info');
  }
  else if (evt.type === 'file_skip') {
    updateQueueRowStatus(current, 'Skipped');
    addLog(`[${current}/${total}] Skipped: ${evt.filename} (Already dubbed)`, 'info');
    appState.lastCompletedPath = evt.output_path;
  }
  else if (evt.type === 'file_complete') {
    updateQueueRowStatus(current, 'Completed');
    progressBarFill.style.width = '100%';
    progressPercentLabel.textContent = '100%';
    addLog(`[${current}/${total}] Completed: ${evt.filename} -> ${evt.output_path}`, 'success');
    appState.lastCompletedPath = evt.output_path;
  }
  else if (evt.type === 'file_error') {
    updateQueueRowStatus(current, 'Failed');
    addLog(`[${current}/${total}] Failed: ${evt.filename} (${evt.error})`, 'error');
  }
  else if (evt.type === 'batch_complete') {
    markAllStagesCompleted();
    progressBarFill.style.width = '100%';
    progressPercentLabel.textContent = '100%';
    pipelineStatusLabel.textContent = 'Completed';
    currentActionLabel.textContent = evt.message;
    addLog(`✓ ${evt.message}`, 'success');

    if (evt.successful && evt.successful.length > 0) {
      appState.lastCompletedPath = evt.successful[evt.successful.length - 1];
    }
    // Strictly NO popup modal - user clicks [ 📂 Open Export Folder ] on toolbar when ready
  }
  else if (evt.type === 'cancelled') {
    addLog(`Cancelled: ${evt.message}`, 'warning');
    pipelineStatusLabel.textContent = 'Cancelled';
  }
  else if (evt.type === 'error') {
    addLog(`Error: ${evt.message}`, 'error');
    pipelineStatusLabel.textContent = 'Error';
  }
});

window.api.onDubFinished(({ exitCode }) => {
  appState.isDubbing = false;
  btnStartDubbing.classList.remove('hidden');
  btnCancelDubbing.classList.add('hidden');
  const isLicensed = appState.systemStatus && appState.systemStatus.licensed;
  setWorkspaceLocked(!isLicensed);
});

function updateQueueRowStatus(index, status) {
  if (appState.queue[index - 1]) {
    appState.queue[index - 1].status = status;
  }
  const row = document.getElementById(`queueRow_${index}`);
  if (row) {
    const tdStatus = row.cells[4];
    if (tdStatus) {
      if (status === 'Processing') tdStatus.innerHTML = `<span class="status-pill processing">Processing</span>`;
      else if (status === 'Completed') tdStatus.innerHTML = `<span class="status-pill completed">✓ Done</span>`;
      else if (status === 'Skipped') tdStatus.innerHTML = `<span class="status-pill skipped">⚡ Dubbed</span>`;
      else if (status === 'Failed') tdStatus.innerHTML = `<span class="status-pill failed">✗ Failed</span>`;
    }
  }
}

// ── License Modal ────────────────────────────────────────────────────────────
btnLicenseStatus.addEventListener('click', () => {
  updateRealtimeClockAndCountdown();
  modalActivation.classList.remove('hidden');
});

btnCloseActivation.addEventListener('click', () => {
  modalActivation.classList.add('hidden');
});

btnCopyMachineId.addEventListener('click', () => {
  navigator.clipboard.writeText(txtMachineId.value);
  btnCopyMachineId.textContent = '✓ Copied!';
  setTimeout(() => { btnCopyMachineId.textContent = '📋 Copy ID'; }, 1800);
});

btnContactTelegram.addEventListener('click', () => {
  // Open Telegram in default browser
  window.open('https://t.me/Tithyaka', '_blank');
});

btnTelegram.addEventListener('click', () => {
  window.open('https://t.me/Tithyaka', '_blank');
});

btnSubmitActivation.addEventListener('click', async () => {
  const key = txtActivationKey.value.trim();
  if (!key) {
    activationAlert.className = 'alert-box error';
    activationAlert.textContent = 'Please enter an activation key.';
    activationAlert.classList.remove('hidden');
    return;
  }

  btnSubmitActivation.disabled = true;
  btnSubmitActivation.textContent = 'Verifying...';

  try {
    const res = await window.api.activateLicense(key);
    if (res.success) {
      activationAlert.className = 'alert-box success';
      activationAlert.textContent = res.message || 'License successfully activated!';
      activationAlert.classList.remove('hidden');

      const status = await window.api.getStatus();
      appState.systemStatus = status;
      updateLicenseDisplay(status);

      setTimeout(() => {
        modalActivation.classList.add('hidden');
        activationAlert.classList.add('hidden');
      }, 1500);
    } else {
      activationAlert.className = 'alert-box error';
      activationAlert.textContent = res.message || 'Activation failed.';
      activationAlert.classList.remove('hidden');
    }
  } catch (err) {
    activationAlert.className = 'alert-box error';
    activationAlert.textContent = err.message;
    activationAlert.classList.remove('hidden');
  } finally {
    btnSubmitActivation.disabled = false;
    btnSubmitActivation.textContent = '⚡ Activate License';
  }
});

const btnStartTrial = document.getElementById('btnStartTrial');
if (btnStartTrial) {
  btnStartTrial.addEventListener('click', async () => {
    const trialAlertBox = document.getElementById('trialAlertBox');
    btnStartTrial.disabled = true;
    btnStartTrial.textContent = 'Activating 3-Hour Trial...';
    if (trialAlertBox) trialAlertBox.classList.add('hidden');

    try {
      const res = await window.api.startTrial();
      if (res.success) {
        if (trialAlertBox) {
          trialAlertBox.className = 'alert-box success';
          trialAlertBox.textContent = '🎁 3-Hour Free Trial Activated! Software unlocked for 3 hours.';
          trialAlertBox.classList.remove('hidden');
        }

        const status = await window.api.getStatus();
        appState.systemStatus = status;
        updateLicenseDisplay(status);

        addLog('🎁 3-Hour Free Trial started successfully. Full video dubbing & export unlocked!', 'success');

        setTimeout(() => {
          modalActivation.classList.add('hidden');
          if (trialAlertBox) trialAlertBox.classList.add('hidden');
        }, 1500);
      } else {
        if (trialAlertBox) {
          trialAlertBox.className = 'alert-box error';
          trialAlertBox.textContent = res.message || 'Trial activation failed.';
          trialAlertBox.classList.remove('hidden');
        }
        btnStartTrial.disabled = true;
        btnStartTrial.textContent = '❌ Trial Already Used on this PC';
      }
    } catch (err) {
      if (trialAlertBox) {
        trialAlertBox.className = 'alert-box error';
        trialAlertBox.textContent = err.message;
        trialAlertBox.classList.remove('hidden');
      }
      btnStartTrial.disabled = false;
      btnStartTrial.textContent = '🎁 Start 3-Hour Free Trial';
    }
  });
}

// ── Settings Modal ───────────────────────────────────────────────────────────
btnOpenSettings.addEventListener('click', () => {
  modalSettings.classList.remove('hidden');
});

btnCloseSettings.addEventListener('click', () => {
  modalSettings.classList.add('hidden');
});

btnSettingsBrowseDir.addEventListener('click', async () => {
  const dir = await window.api.selectExportFolder();
  if (dir) {
    txtSettingsExportDir.value = dir;
    txtExportFolder.value = dir;
  }
});

btnSaveSettings.addEventListener('click', async () => {
  const exportDir = txtSettingsExportDir.value;
  txtExportFolder.value = exportDir;
  chkSkipAlreadyDubbed.checked = chkSettingsSkipDubbed.checked;

  await window.api.saveSettings({
    export_folder: exportDir,
    create_movie_folder: chkSettingsCreateMovieFolder.checked,
    auto_open_output: chkSettingsAutoOpen.checked,
    skip_already_dubbed: chkSettingsSkipDubbed.checked,
  });

  addLog('Preferences saved.', 'info');
  modalSettings.classList.add('hidden');
});

// ── Dynamic Version Display & Alerts ───────────────────────────────────────────
function updateAppVersionDisplay(versionStr) {
  const cleanVer = String(versionStr || '1.3.0').trim().replace(/^[vV]/, '');
  const headerVersionBadge = document.getElementById('headerVersionBadge');
  const headerSubtitle = document.getElementById('headerSubtitle');
  const settingsCurrentVersion = document.getElementById('settingsCurrentVersion');

  if (headerVersionBadge) {
    headerVersionBadge.textContent = `v${cleanVer}`;
    headerVersionBadge.className = 'badge-v13 badge-updated-highlight';
  }
  if (headerSubtitle) {
    headerSubtitle.textContent = `AI Video Dubbing & Recap Studio • Version ${cleanVer}`;
  }
  if (settingsCurrentVersion) {
    settingsCurrentVersion.textContent = `v${cleanVer} (Production)`;
  }
  document.title = `Khmer Dubbing — AI Video Dubbing Studio v${cleanVer}`;
}

function showToast(title, message, type = 'info', durationMs = 6000) {
  const toast = document.getElementById('toastNotification');
  const toastTitle = document.getElementById('toastTitle');
  const toastMsg = document.getElementById('toastMessage');
  const toastIcon = document.getElementById('toastIcon');
  if (!toast) return;

  if (toastTitle) toastTitle.textContent = title;
  if (toastMsg) toastMsg.textContent = message;
  if (toastIcon) {
    toastIcon.textContent = type === 'success' ? '🎉' : (type === 'error' ? '⚠️' : 'ℹ️');
  }

  toast.className = `toast-notification ${type}`;
  toast.classList.remove('hidden');

  if (window._toastTimer) clearTimeout(window._toastTimer);
  if (durationMs > 0) {
    window._toastTimer = setTimeout(() => {
      toast.classList.add('hidden');
    }, durationMs);
  }
}

const btnToastClose = document.getElementById('btnToastClose');
if (btnToastClose) {
  btnToastClose.addEventListener('click', () => {
    const toast = document.getElementById('toastNotification');
    if (toast) toast.classList.add('hidden');
  });
}

function playUpdateSuccessChime() {
  try {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const notes = [523.25, 659.25, 783.99, 1046.50]; // C5, E5, G5, C6 celebratory chords
    notes.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, ctx.currentTime + idx * 0.11);
      gain.gain.setValueAtTime(0.001, ctx.currentTime + idx * 0.11);
      gain.gain.exponentialRampToValueAtTime(0.22, ctx.currentTime + idx * 0.11 + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + idx * 0.11 + 0.35);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(ctx.currentTime + idx * 0.11);
      osc.stop(ctx.currentTime + idx * 0.11 + 0.36);
    });
  } catch (e) {
    console.warn('Audio chime notice:', e);
  }
}

// ── Online Auto-Updater Handlers ─────────────────────────────────────────────
const btnUpdateNotice = document.getElementById('btnUpdateNotice');
const txtUpdateNotice = document.getElementById('txtUpdateNotice');
const modalUpdater = document.getElementById('modalUpdater');
const btnCloseUpdater = document.getElementById('btnCloseUpdater');
const btnDismissUpdater = document.getElementById('btnDismissUpdater');
const btnStartDownloadUpdate = document.getElementById('btnStartDownloadUpdate');
const btnRestartApp = document.getElementById('btnRestartApp');
const txtUpdateVersionNow = document.getElementById('txtUpdateVersionNow');
const txtUpdateVersionNew = document.getElementById('txtUpdateVersionNew');
const cardVersionNow = document.getElementById('cardVersionNow');
const cardVersionNew = document.getElementById('cardVersionNew');
const badgeVersionNow = document.getElementById('badgeVersionNow');
const badgeVersionNew = document.getElementById('badgeVersionNew');
const flowArrowSymbol = document.getElementById('flowArrowSymbol');
const flowArrowCaption = document.getElementById('flowArrowCaption');
const modalTitleIcon = document.getElementById('modalTitleIcon');
const modalUpdateHeading = document.getElementById('modalUpdateHeading');
const txtUpdateReleaseDate = document.getElementById('txtUpdateReleaseDate');
const txtUpdateSizeInfoPill = document.getElementById('txtUpdateSizeInfoPill');
const txtUpdateChangelog = document.getElementById('txtUpdateChangelog');
const updateProgressSection = document.getElementById('updateProgressSection');
const txtUpdateStatus = document.getElementById('txtUpdateStatus');
const txtUpdatePercent = document.getElementById('txtUpdatePercent');
const updateProgressBarFill = document.getElementById('updateProgressBarFill');
const txtUpdateSizeInfo = document.getElementById('txtUpdateSizeInfo');
const txtUpdateSpeed = document.getElementById('txtUpdateSpeed');
const updateSuccessAlertCard = document.getElementById('updateSuccessAlertCard');
const updateAlertDetail = document.getElementById('updateAlertDetail');
const updateAlertBox = document.getElementById('updateAlertBox');
const btnCheckUpdatesManual = document.getElementById('btnCheckUpdatesManual');
const settingsUpdateMsg = document.getElementById('settingsUpdateMsg');
const settingsCurrentVersion = document.getElementById('settingsCurrentVersion');

let pendingUpdateInfo = null;

function displayUpdatePrompt(updateInfo) {
  pendingUpdateInfo = updateInfo;
  if (!updateInfo || !updateInfo.updateAvailable) return;

  const currentVer = String(updateInfo.currentVersion || appState.currentVersion || '1.1.0').trim().replace(/^[vV]/, '');
  const newVer = String(updateInfo.newVersion || '1.3.0').trim().replace(/^[vV]/, '');

  if (btnUpdateNotice) {
    btnUpdateNotice.classList.remove('hidden');
    btnUpdateNotice.classList.remove('update-completed');
    if (txtUpdateNotice) {
      txtUpdateNotice.textContent = `Update: v${newVer}`;
    }
  }

  // Populate Realtime Version Transformation Flow
  if (txtUpdateVersionNow) txtUpdateVersionNow.textContent = `v${currentVer}`;
  if (txtUpdateVersionNew) txtUpdateVersionNew.textContent = `v${newVer}`;
  if (badgeVersionNow) {
    badgeVersionNow.textContent = 'VERSION NOW';
    badgeVersionNow.className = 'version-flow-badge';
  }
  if (cardVersionNow) {
    cardVersionNow.classList.remove('version-card-success-glow');
  }
  if (flowArrowSymbol) flowArrowSymbol.textContent = '➔';
  if (flowArrowCaption) flowArrowCaption.textContent = 'UPGRADE';
  if (badgeVersionNew) {
    badgeVersionNew.textContent = 'NEW VERSION';
    badgeVersionNew.className = 'version-flow-badge badge-new';
  }

  if (txtUpdateReleaseDate) txtUpdateReleaseDate.textContent = `📅 Released: ${updateInfo.releaseDate || 'Today'}`;
  if (txtUpdateSizeInfoPill) {
    txtUpdateSizeInfoPill.textContent = updateInfo.fileSizeMb ? `📦 ${updateInfo.fileSizeMb} MB Patch` : '📦 Update Patch';
  }
  if (txtUpdateChangelog) txtUpdateChangelog.textContent = updateInfo.changelog || 'Performance improvements, translation accuracy, and stability enhancements.';

  // Reset modal state
  if (updateProgressSection) updateProgressSection.classList.add('hidden');
  if (updateSuccessAlertCard) updateSuccessAlertCard.classList.add('hidden');
  if (updateAlertBox) updateAlertBox.classList.add('hidden');
  if (modalTitleIcon) modalTitleIcon.textContent = '🚀';
  if (modalUpdateHeading) modalUpdateHeading.textContent = 'Software Update Available';
  if (btnStartDownloadUpdate) {
    btnStartDownloadUpdate.classList.remove('hidden');
    btnStartDownloadUpdate.disabled = false;
  }
  if (btnDismissUpdater) btnDismissUpdater.disabled = false;
  if (btnCloseUpdater) btnCloseUpdater.disabled = false;
  if (btnRestartApp) btnRestartApp.classList.add('hidden');
}

if (window.api && typeof window.api.onUpdateAvailable === 'function') {
  window.api.onUpdateAvailable((info) => {
    displayUpdatePrompt(info);
    addLog(`🚀 Online software update available: v${info.newVersion}`, 'info');
    showToast('🚀 Software Update Available', `Version v${info.newVersion} is ready for installation.`, 'info', 6000);
  });
}

if (window.api && typeof window.api.onUpdateProgress === 'function') {
  window.api.onUpdateProgress((p) => {
    if (updateProgressBarFill) updateProgressBarFill.style.width = `${p.percent}%`;
    if (txtUpdatePercent) txtUpdatePercent.textContent = `${p.percent}%`;
    if (txtUpdateSizeInfo) txtUpdateSizeInfo.textContent = `${p.downloadedMb} MB / ${p.totalMb} MB`;
    if (txtUpdateSpeed) txtUpdateSpeed.textContent = `${p.speedMb} MB/s`;
  });
}

if (btnUpdateNotice) {
  btnUpdateNotice.addEventListener('click', () => {
    if (pendingUpdateInfo) {
      displayUpdatePrompt(pendingUpdateInfo);
      modalUpdater.classList.remove('hidden');
    }
  });
}

if (btnCloseUpdater) {
  btnCloseUpdater.addEventListener('click', () => {
    modalUpdater.classList.add('hidden');
  });
}

if (btnDismissUpdater) {
  btnDismissUpdater.addEventListener('click', () => {
    modalUpdater.classList.add('hidden');
  });
}

if (btnCheckUpdatesManual) {
  btnCheckUpdatesManual.addEventListener('click', async () => {
    settingsUpdateMsg.className = 'settings-update-msg info';
    settingsUpdateMsg.textContent = 'Checking for updates...';
    settingsUpdateMsg.classList.remove('hidden');
    btnCheckUpdatesManual.disabled = true;

    try {
      const res = await window.api.checkForUpdates();
      if (res && res.updateAvailable) {
        settingsUpdateMsg.className = 'settings-update-msg success';
        settingsUpdateMsg.textContent = `🚀 Update v${res.newVersion} available!`;
        displayUpdatePrompt(res);
        modalSettings.classList.add('hidden');
        modalUpdater.classList.remove('hidden');
      } else if (res && res.error) {
        settingsUpdateMsg.className = 'settings-update-msg error';
        settingsUpdateMsg.textContent = `Could not reach update server: ${res.error}`;
      } else {
        const curVer = res.currentVersion || appState.currentVersion || '1.3.0';
        settingsUpdateMsg.className = 'settings-update-msg success';
        settingsUpdateMsg.textContent = `✓ You are already using the latest version (v${curVer}).`;
        showToast('✓ Up to Date', `You are running the latest version of Khmer Dubbing Studio (v${curVer}).`, 'info', 4000);
      }
    } catch (err) {
      settingsUpdateMsg.className = 'settings-update-msg error';
      settingsUpdateMsg.textContent = `Check failed: ${err.message}`;
    } finally {
      btnCheckUpdatesManual.disabled = false;
    }
  });
}

if (btnStartDownloadUpdate) {
  btnStartDownloadUpdate.addEventListener('click', async () => {
    if (!pendingUpdateInfo || !pendingUpdateInfo.downloadUrl) {
      alert('Download URL not found in update manifest.');
      return;
    }

    btnStartDownloadUpdate.disabled = true;
    btnDismissUpdater.disabled = true;
    if (btnCloseUpdater) btnCloseUpdater.disabled = true;
    updateProgressSection.classList.remove('hidden');
    txtUpdateStatus.textContent = 'Downloading update patch...';
    updateProgressBarFill.style.width = '0%';
    txtUpdatePercent.textContent = '0%';
    if (updateAlertBox) updateAlertBox.classList.add('hidden');
    if (updateSuccessAlertCard) updateSuccessAlertCard.classList.add('hidden');

    try {
      const res = await window.api.downloadAndApplyUpdate({
        downloadUrl: pendingUpdateInfo.downloadUrl,
        newVersion: pendingUpdateInfo.newVersion
      });

      if (res && res.success) {
        const oldVer = String(pendingUpdateInfo.currentVersion || appState.currentVersion || '1.1.0').trim().replace(/^[vV]/, '');
        const newVer = String(pendingUpdateInfo.newVersion || '1.3.0').trim().replace(/^[vV]/, '');

        // 1. AUTO CHANGE "VERSION NOW" TO "NEW VERSION" IN REALTIME IN THE UI
        if (txtUpdateVersionNow) {
          txtUpdateVersionNow.textContent = `v${newVer}`;
        }
        if (badgeVersionNow) {
          badgeVersionNow.textContent = 'UPDATED (NOW)';
          badgeVersionNow.className = 'version-flow-badge badge-updated';
        }
        if (cardVersionNow) {
          cardVersionNow.classList.add('version-card-success-glow');
        }
        if (flowArrowSymbol) flowArrowSymbol.textContent = '✓';
        if (flowArrowCaption) flowArrowCaption.textContent = 'APPLIED';
        if (badgeVersionNew) {
          badgeVersionNew.textContent = 'ACTIVE';
          badgeVersionNew.className = 'version-flow-badge badge-active';
        }

        // 2. AUTO CHANGE HEADER BADGE, SUBTITLE, AND SETTINGS VERSION
        updateAppVersionDisplay(newVer);
        if (settingsCurrentVersion) {
          settingsCurrentVersion.textContent = `v${newVer} (Production - Updated)`;
          settingsCurrentVersion.classList.add('version-updated-glow');
        }
        if (btnUpdateNotice) {
          btnUpdateNotice.classList.add('update-completed');
          if (txtUpdateNotice) txtUpdateNotice.textContent = `✓ Updated: v${newVer}`;
        }

        // 3. UPDATE MODAL STATE AND DISPLAY CELEBRATION ALERT CARD
        if (modalTitleIcon) modalTitleIcon.textContent = '🎉';
        if (modalUpdateHeading) modalUpdateHeading.textContent = 'Update Installed Successfully!';
        txtUpdateStatus.textContent = `✓ Version ${newVer} successfully installed!`;
        
        if (updateSuccessAlertCard) {
          if (updateAlertDetail) {
            updateAlertDetail.innerHTML = `Version automatically updated from <span class="old-ver-strike">v${oldVer}</span> to <strong class="text-highlight">v${newVer}</strong>!`;
          }
          updateSuccessAlertCard.classList.remove('hidden');
        }

        // 4. AUDIO ALERT (CELEBRATORY CHIME)
        playUpdateSuccessChime();

        // 5. GLOBAL TOAST ALERT
        showToast(
          '🎉 Software Updated Successfully!',
          `Version automatically changed from v${oldVer} to v${newVer}. Restarting application to apply all changes...`,
          'success',
          8000
        );

        // 6. ACTIVITY LOG NOTIFICATION
        addLog(`🎉 Software update applied! Version changed from v${oldVer} to v${newVer}. Restarting to finalize...`, 'success');

        // 7. RECORD FOR POST-RESTART WELCOME
        try {
          localStorage.setItem('just_updated_to', newVer);
        } catch (e) {}

        // 8. UPDATE BUTTONS & RESTART COUNTDOWN
        btnStartDownloadUpdate.classList.add('hidden');
        btnRestartApp.classList.remove('hidden');

        let count = 4;
        btnRestartApp.textContent = `🔄 Restarting in ${count}s... (Click to Restart Now)`;
        const timer = setInterval(() => {
          count--;
          if (count > 0) {
            btnRestartApp.textContent = `🔄 Restarting in ${count}s... (Click to Restart Now)`;
          } else {
            clearInterval(timer);
            window.api.restartApp();
          }
        }, 1000);
      } else {
        txtUpdateStatus.textContent = 'Update failed';
        if (updateAlertBox) {
          updateAlertBox.className = 'alert-box error';
          updateAlertBox.textContent = res ? res.error : 'Failed to apply update.';
          updateAlertBox.classList.remove('hidden');
        }
        btnStartDownloadUpdate.disabled = false;
        btnDismissUpdater.disabled = false;
        if (btnCloseUpdater) btnCloseUpdater.disabled = false;
      }
    } catch (err) {
      txtUpdateStatus.textContent = 'Download error';
      if (updateAlertBox) {
        updateAlertBox.className = 'alert-box error';
        updateAlertBox.textContent = err.message;
        updateAlertBox.classList.remove('hidden');
      }
      btnStartDownloadUpdate.disabled = false;
      btnDismissUpdater.disabled = false;
      if (btnCloseUpdater) btnCloseUpdater.disabled = false;
    }
  });
}

if (btnRestartApp) {
  btnRestartApp.addEventListener('click', () => {
    window.api.restartApp();
  });
}

// Run startup
initApp();
