const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const { spawn, execFile, exec } = require('child_process');
const updater = require('./updater');

let mainWindow = null;
let currentDubProcess = null;

const PROJECT_ROOT = path.resolve(__dirname, '..');
const ICON_PATH = path.join(PROJECT_ROOT, 'assets', 'icon.ico');

// Resolve path to the backend engine
function getEngineConfig() {
  const isPackaged = app.isPackaged;

  // Add all possible bin/ffmpeg directories to process.env.PATH
  const binCandidates = [
    path.join(path.dirname(process.execPath), 'bin'),
    path.join(process.resourcesPath, 'bin'),
    path.join(PROJECT_ROOT, 'bin'),
    'C:\\ffmpeg\\bin',
    'C:\\Program Files\\ffmpeg\\bin',
  ];
  for (const b of binCandidates) {
    if (fs.existsSync(b) && !process.env.PATH.includes(b)) {
      process.env.PATH = `${b};${process.env.PATH}`;
    }
  }

  if (isPackaged) {
    const candidates = [
      path.join(process.resourcesPath, 'engine', 'dubber_engine.exe'),
      path.join(process.resourcesPath, 'engine', 'dubber_engine', 'dubber_engine.exe'),
      path.join(path.dirname(process.execPath), 'engine', 'dubber_engine.exe'),
      path.join(path.dirname(process.execPath), 'engine', 'dubber_engine', 'dubber_engine.exe'),
      path.join(path.dirname(process.execPath), 'dubber_engine.exe'),
    ];
    for (const c of candidates) {
      if (fs.existsSync(c)) {
        return { cmd: c, args: [], cwd: path.dirname(c) };
      }
    }
  }

  // Development or fallback: Check project virtualenv with functional fallback to system Python
  const venvPython = path.join(PROJECT_ROOT, 'venv', 'Scripts', 'python.exe');
  let pythonCmd = 'python';
  if (fs.existsSync(venvPython)) {
    try {
      const { spawnSync } = require('child_process');
      const test = spawnSync(venvPython, ['--version'], { timeout: 2000 });
      if (test.status === 0) {
        pythonCmd = venvPython;
      }
    } catch (e) {
      pythonCmd = 'python';
    }
  }
  const scriptPath = path.join(PROJECT_ROOT, 'engine.py');

  return {
    cmd: pythonCmd,
    args: [scriptPath],
    cwd: PROJECT_ROOT
  };
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 820,
    minWidth: 1080,
    minHeight: 700,
    backgroundColor: '#0d1117',
    icon: fs.existsSync(ICON_PATH) ? ICON_PATH : undefined,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
    autoHideMenuBar: true,
    show: false,
  });

  mainWindow.loadFile(path.join(__dirname, 'index.html'));

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();

    // Check for updates in the background after 3 seconds
    setTimeout(async () => {
      try {
        const configPath = path.join(PROJECT_ROOT, 'config.json');
        let manifestUrl = null;
        if (fs.existsSync(configPath)) {
          try {
            const cfg = JSON.parse(fs.readFileSync(configPath, 'utf8'));
            if (cfg.update_manifest_url) manifestUrl = cfg.update_manifest_url;
          } catch (e) {}
        }
        const currentVer = app.getVersion() || '1.3.0';
        const res = await updater.checkForUpdates(currentVer, manifestUrl);
        if (res && res.updateAvailable && mainWindow && !mainWindow.isDestroyed()) {
          mainWindow.webContents.send('update-available', res);
        }
      } catch (err) {}
    }, 3000);
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
    if (currentDubProcess) {
      try {
        currentDubProcess.kill();
      } catch (e) {}
      currentDubProcess = null;
    }
  });
}

// IPC Helpers to execute engine subcommands and return JSON
function runEngineJson(subcommand, extraArgs = []) {
  return new Promise((resolve) => {
    const engine = getEngineConfig();
    const finalArgs = [...engine.args, subcommand, ...extraArgs];

    execFile(
      engine.cmd,
      finalArgs,
      {
        cwd: engine.cwd,
        encoding: 'utf8',
        maxBuffer: 10 * 1024 * 1024,
        windowsHide: true,
        env: { ...process.env, PYTHONIOENCODING: 'utf-8', PYTHONUTF8: '1' }
      },
      (err, stdout, stderr) => {
      if (err && !stdout) {
        resolve({ success: false, error: err.message || stderr });
        return;
      }
      try {
        const parsed = JSON.parse(stdout.trim());
        resolve(parsed);
      } catch (parseErr) {
        resolve({ success: false, error: 'Invalid response from engine: ' + stdout });
      }
    });
  });
}

// ── IPC Handlers ─────────────────────────────────────────────────────────────

ipcMain.handle('get-status', async () => {
  const status = await runEngineJson('status');
  if (status && typeof status === 'object') {
    status.app_version = app.getVersion() || '1.3.0';
  }
  return status;
});

ipcMain.handle('get-app-version', () => {
  return app.getVersion() || '1.3.0';
});

ipcMain.handle('activate-license', async (event, key) => {
  return await runEngineJson('activate', ['--key', key]);
});

ipcMain.handle('start-trial', async () => {
  return await runEngineJson('start-trial');
});

ipcMain.handle('probe-files', async (event, filePaths) => {
  return await runEngineJson('probe', ['--files', ...filePaths]);
});

ipcMain.handle('save-settings', async (event, settingsObj) => {
  return await runEngineJson('save-config', ['--config-json', JSON.stringify(settingsObj)]);
});

ipcMain.handle('select-files', async () => {
  if (!mainWindow) return [];
  const result = await dialog.showOpenDialog(mainWindow, {
    title: 'Select Video File(s)',
    properties: ['openFile', 'multiSelections'],
    filters: [
      { name: 'Video Files', extensions: ['mp4', 'mkv', 'avi', 'mov', 'webm', 'm4v', 'flv', 'wmv', 'ts'] },
      { name: 'All Files', extensions: ['*'] }
    ]
  });
  if (result.canceled || !result.filePaths) return [];
  return result.filePaths;
});

ipcMain.handle('select-folder', async () => {
  if (!mainWindow) return null;
  const result = await dialog.showOpenDialog(mainWindow, {
    title: 'Select Video Folder (Batch Import)',
    properties: ['openDirectory']
  });
  if (result.canceled || !result.filePaths || result.filePaths.length === 0) return null;
  return result.filePaths[0];
});

ipcMain.handle('select-export-folder', async () => {
  if (!mainWindow) return null;
  const result = await dialog.showOpenDialog(mainWindow, {
    title: 'Select Export Destination Folder',
    properties: ['openDirectory', 'createDirectory']
  });
  if (result.canceled || !result.filePaths || result.filePaths.length === 0) return null;
  return result.filePaths[0];
});

ipcMain.handle('open-folder', async (event, folderPath) => {
  if (!folderPath) return false;
  try {
    const resolved = path.resolve(folderPath);
    if (!fs.existsSync(resolved)) {
      fs.mkdirSync(resolved, { recursive: true });
    }
    const res = await shell.openPath(resolved);
    if (res) {
      // Fallback
      exec(`explorer "${resolved}"`);
    }
    return true;
  } catch (err) {
    exec(`explorer "${folderPath}"`);
    return true;
  }
});

ipcMain.handle('open-file', async (event, filePath) => {
  if (!filePath) return false;
  try {
    const resolved = path.resolve(filePath);
    const res = await shell.openPath(resolved);
    return !res;
  } catch (err) {
    return false;
  }
});

ipcMain.handle('start-dub', async (event, options) => {
  if (currentDubProcess) {
    return { started: false, error: 'A dubbing process is already running.' };
  }

  const engine = getEngineConfig();
  const args = [...engine.args, 'dub', '--files', ...options.files];
  if (options.vocalMode) {
    args.push('--vocal-mode', options.vocalMode);
  }
  if (options.exportFolder) {
    args.push('--export-folder', options.exportFolder);
  }
  if (options.skipExisting !== undefined) {
    args.push('--skip-existing', options.skipExisting ? '1' : '0');
  }

  try {
    currentDubProcess = spawn(engine.cmd, args, {
      cwd: engine.cwd,
      stdio: ['ignore', 'pipe', 'pipe'],
      windowsHide: true,
      env: { ...process.env, PYTHONIOENCODING: 'utf-8', PYTHONUTF8: '1' }
    });

    let buffer = '';

    currentDubProcess.stdout.on('data', (data) => {
      buffer += data.toString('utf8');
      const lines = buffer.split('\n');
      buffer = lines.pop(); // Keep unfinished line in buffer

      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed) continue;
        try {
          const parsed = JSON.parse(trimmed);
          if (mainWindow && !mainWindow.isDestroyed()) {
            mainWindow.webContents.send('dub-event', parsed);
          }
        } catch (e) {
          // Plain log or unformatted text
          if (mainWindow && !mainWindow.isDestroyed()) {
            mainWindow.webContents.send('dub-event', {
              type: 'log',
              message: trimmed,
              status: 'info'
            });
          }
        }
      }
    });

    currentDubProcess.stderr.on('data', (data) => {
      const errText = data.toString('utf8').trim();
      if (errText && mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send('dub-event', {
          type: 'log',
          message: errText,
          status: 'warning'
        });
      }
    });

    currentDubProcess.on('close', (code) => {
      currentDubProcess = null;
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send('dub-finished', { exitCode: code });
      }
    });

    return { started: true };
  } catch (err) {
    currentDubProcess = null;
    return { started: false, error: err.message };
  }
});

ipcMain.handle('cancel-dub', async () => {
  if (currentDubProcess) {
    try {
      currentDubProcess.kill('SIGINT');
      setTimeout(() => {
        if (currentDubProcess) {
          currentDubProcess.kill('SIGKILL');
          currentDubProcess = null;
        }
      }, 1000);
      return { success: true };
    } catch (e) {
      return { success: false, error: e.message };
    }
  }
  return { success: true };
});

// ── Auto-Updater IPC Handlers ────────────────────────────────────────────────
ipcMain.handle('check-for-updates', async () => {
  const configPath = path.join(PROJECT_ROOT, 'config.json');
  let manifestUrl = null;
  if (fs.existsSync(configPath)) {
    try {
      const cfg = JSON.parse(fs.readFileSync(configPath, 'utf8'));
      if (cfg.update_manifest_url) manifestUrl = cfg.update_manifest_url;
    } catch (e) {}
  }
  const currentVer = app.getVersion() || '1.3.0';
  return await updater.checkForUpdates(currentVer, manifestUrl);
});

ipcMain.handle('download-and-apply-update', async (event, { downloadUrl, newVersion }) => {
  if (!downloadUrl) return { success: false, error: 'No download URL provided.' };
  try {
    const targetZip = path.join(updater.UPDATES_DIR, `patch_${newVersion || Date.now()}.zip`);
    await updater.downloadFile(downloadUrl, targetZip, (progress) => {
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send('update-download-progress', progress);
      }
    });
    const applyRes = updater.applyPatchZip(targetZip);
    return applyRes;
  } catch (err) {
    return { success: false, error: err.message };
  }
});

ipcMain.handle('restart-app', () => {
  updater.restartApp();
});

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});
