const { contextBridge, ipcRenderer, webUtils } = require('electron');

contextBridge.exposeInMainWorld('api', {
  getStatus: () => ipcRenderer.invoke('get-status'),
  activateLicense: (key) => ipcRenderer.invoke('activate-license', key),
  startTrial: () => ipcRenderer.invoke('start-trial'),
  probeFiles: (filePaths) => ipcRenderer.invoke('probe-files', filePaths),
  saveSettings: (settingsObj) => ipcRenderer.invoke('save-settings', settingsObj),
  selectFiles: () => ipcRenderer.invoke('select-files'),
  selectFolder: () => ipcRenderer.invoke('select-folder'),
  selectExportFolder: () => ipcRenderer.invoke('select-export-folder'),
  openFolder: (folderPath) => ipcRenderer.invoke('open-folder', folderPath),
  openFile: (filePath) => ipcRenderer.invoke('open-file', filePath),
  startDub: (options) => ipcRenderer.invoke('start-dub', options),
  cancelDub: () => ipcRenderer.invoke('cancel-dub'),
  getPathForFile: (file) => {
    try {
      if (webUtils && typeof webUtils.getPathForFile === 'function') {
        return webUtils.getPathForFile(file);
      }
    } catch (e) {
      console.warn('getPathForFile fallback:', e);
    }
    return file ? (file.path || '') : '';
  },
  onDubEvent: (callback) => {
    ipcRenderer.on('dub-event', (event, data) => callback(data));
  },
  onDubFinished: (callback) => {
    ipcRenderer.on('dub-finished', (event, data) => callback(data));
  },
  checkForUpdates: () => ipcRenderer.invoke('check-for-updates'),
  downloadAndApplyUpdate: (params) => ipcRenderer.invoke('download-and-apply-update', params),
  restartApp: () => ipcRenderer.invoke('restart-app'),
  onUpdateAvailable: (callback) => {
    ipcRenderer.on('update-available', (event, data) => callback(data));
  },
  onUpdateProgress: (callback) => {
    ipcRenderer.on('update-download-progress', (event, data) => callback(data));
  }
});
